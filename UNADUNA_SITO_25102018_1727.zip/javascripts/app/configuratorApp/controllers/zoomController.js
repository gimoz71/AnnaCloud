var configModule = angular.module('configuratorModule');
configModule.controller("zoomController", function($scope, $http, $window, zoomService) {
	
	this.getZoomImageMerged = function(){
		
	}
})